<?php
include_once('../conectaBD.php');

$id = $_GET['id'];

$consulta = $conn->prepare("SELECT * FROM cliente WHERE id=:id");
$consulta->execute([':id' => $id]);

if($consulta->rowCount() > 0 ){
    while($row = $consulta->fetch(PDO::FETCH_ASSOC)){
        $nome = $row['nome'];
        $endereco = $row['endereco'];
        $cpf = $row['cpf'];
        $empresa = $row['empresa'];
        $contato = $row['contato'];
        $id = $row['id'];

    }
}else{
    echo 'FALHA';
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/cadastro.css">
    <title>Cadastro</title>
</head>
<body>

<script>
  $("#fecharjanela").click(function(){
   $("#fechar_form").remove();
   })
</script>


<div class="cadastro_form" id="fechar_form">


    <a href="#" id="fecharjanela" class="fechar_cadastro">X</a>
        
    
    <form action="update_cliente.php" method="post">
    <h2>Atualizar Cliente</h2><br>
            <input type="text" value="<?php echo $nome;?>" name="nome"><br>
            <input type="text" value="<?php echo $endereco;?>" name="endereco"><br>
            <input type="text" value="<?php echo $cpf;?>" name="cpf"><br><br>

            <input type="text" value="<?php echo $empresa;?>" name="empresa"><br>
            <input type="text" value="<?php echo $contato;?>" name="contato"><br><br>
            <input type="hidden" value="<?php echo $id;?>" name="id"><br><br>
            <input type="submit" value="Atualizar" id="input">
        </form>

</div>

</body>
</html>